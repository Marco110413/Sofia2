from __future__ import annotations

from poetry.core.exceptions.base import PoetryCoreError


__all__ = ("PoetryCoreError",)
